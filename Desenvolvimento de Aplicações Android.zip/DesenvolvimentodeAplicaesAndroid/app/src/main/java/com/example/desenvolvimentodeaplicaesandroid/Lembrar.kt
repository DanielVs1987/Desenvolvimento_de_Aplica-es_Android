package com.example.desenvolvimentodeaplicaesandroid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class Lembrar : AppCompatActivity() {


    private lateinit var buscarButton: Button
    private lateinit var tituloEditText: EditText
    private lateinit var mensagemTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lembrar)

        val buttonOpenLembrarVoltar = findViewById<Button>(R.id.LembrarVoltar)
        buttonOpenLembrarVoltar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        tituloEditText = findViewById(R.id.TituloEditText)
        mensagemTextView = findViewById(R.id.SuaMensagem)
        buscarButton = findViewById(R.id.BuscarButton)

        buscarButton.setOnClickListener {
            val titulo = tituloEditText.text.toString()
            val jsonLembrete = lerArquivoJSON("lembrete.json")

            jsonLembrete?.let {
                val tituloSalvo = it.getString("titulo")
                val textoSalvo = it.getString("texto")

                if (titulo == tituloSalvo) {
                    mensagemTextView.text = textoSalvo
                } else {
                    mensagemTextView.text = "Nenhum lembrete encontrado com esse título."
                }
            }
        }
    }

    private fun lerArquivoJSON(nomeArquivo: String): JSONObject? {
        return try {
            val inputStream = openFileInput(nomeArquivo)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val stringBuilder = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                stringBuilder.append(line)
            }
            reader.close()
            JSONObject(stringBuilder.toString())
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}