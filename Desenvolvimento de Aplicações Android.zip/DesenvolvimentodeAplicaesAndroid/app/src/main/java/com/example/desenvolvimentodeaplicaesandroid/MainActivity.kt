package com.example.desenvolvimentodeaplicaesandroid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val buttonOpenLembrar = findViewById<Button>(R.id.AtLembrar)
        buttonOpenLembrar.setOnClickListener {
            val intent = Intent(this, Lembrar::class.java)
            startActivity(intent)
        }

        val buttonOpenMemorizar = findViewById<Button>(R.id.AtMemorizar)
        buttonOpenMemorizar.setOnClickListener {
            val intent = Intent(this, Memorizar::class.java)
            startActivity(intent)
        }

    }
}