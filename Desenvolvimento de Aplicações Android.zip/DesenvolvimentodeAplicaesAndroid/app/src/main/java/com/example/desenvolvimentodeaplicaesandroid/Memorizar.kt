package com.example.desenvolvimentodeaplicaesandroid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.FileOutputStream
import java.io.OutputStreamWriter


class Memorizar : AppCompatActivity() {

    private lateinit var tituloLembrete: EditText
    private lateinit var textoLembrete: EditText
    private lateinit var botaoSalvar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_memorizar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonOpenMemorizarVoltar = findViewById<Button>(R.id.MemorizarVoltar)
        buttonOpenMemorizarVoltar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        tituloLembrete = findViewById(R.id.TituloLembrete)
        textoLembrete = findViewById(R.id.TextoLembrete)
        botaoSalvar = findViewById(R.id.BotaoSalvar)

        botaoSalvar.setOnClickListener {
            try {
                val jsonLembrete = JSONObject()
                jsonLembrete.put("titulo", tituloLembrete.text.toString())
                jsonLembrete.put("texto", textoLembrete.text.toString())

                val fos: FileOutputStream = openFileOutput("lembrete.json", MODE_PRIVATE)
                val osw = OutputStreamWriter(fos)
                osw.write(jsonLembrete.toString())
                osw.close()
                fos.close()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }
}